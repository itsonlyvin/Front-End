package com.finalproject.vinayakv.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finalproject.vinayakv.LoginRepository.LoginRepository;
import com.finalproject.vinayakv.UserDomain.User;

@Service
	public class LoginService {
	    
	    @Autowired
	    private LoginRepository repo;
	  
	    	public User login(String username, String password) {
	      User user = repo.findByUsernameAndPassword(username, password);
	      return user;
	  }
	    
	}