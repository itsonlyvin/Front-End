package com.finalproject.vinayakv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VinayakvApplicationTests {

	@Test
	void contextLoads() {
	}

}
